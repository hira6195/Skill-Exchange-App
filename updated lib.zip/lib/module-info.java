module skill.exchange {
}