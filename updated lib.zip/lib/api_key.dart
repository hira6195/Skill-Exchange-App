class ApiKey {
  static const String geminiApiKey = "AQ.Ab8RN6KG6tIfawQOD4Z3o7XDWUhzYz0O7QTD0NmWbA3J2Ri64w";
}